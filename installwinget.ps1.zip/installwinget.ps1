#Allow scripts to run#
regedit.exe /S EnableScripts.reg

#Create title and run via foreach loop using write-host#
foreach ($char in [char[]]$string){
    switch ($char){
        ' ' { Write-Host "  " -NoNewline }
        '#' { Write-Host "  " -BackgroundColor $FontColor -NoNewline }
        "`n'"{ Write-Host $_ -NoNewline }
    }
}

@"
-----------------------------------------------------------------------------------------------------
 _    _      _                              _          _         _____          _        _ _       
 | |  | |    | |                            | |        | |       |_   _|        | |      | | |      
 | |  | | ___| | ___ ___  _ __ ___   ___    | |     ___| |_ ___    | | _ __  ___| |_ __ _| | |      
 | |/\| |/ _ \ |/ __/ _ \| '_ ` _ \ / _ \   | |    / _ \ __/ __|   | || '_ \/ __| __/ _` | | |      
 \  /\  /  __/ | (_| (_) | | | | | |  __/_  | |___|  __/ |_\__ \  _| || | | \__ \ || (_| | | |_ _ _ 
  \/  \/ \___|_|\___\___/|_| |_| |_|\___( ) \_____/\___|\__|___/  \___/_| |_|___/\__\__,_|_|_(_|_|_)
                                      |/                                                          
------------------------------------------------------------------------------------------------------
"@

#Download and Install winget package manager#
ECHO "Downloading from github..."

Invoke-WebRequest https://github.com/microsoft/winget-cli/releases/download/v1.0.11451/Microsoft.DesktopAppInstaller_8wekyb3d8bbwe.appxbundle -OutFile "$env:userprofile\Downloads\Microsoft.DesktopAppInstaller_8wekyb3d8bbwe.appxbundle" -UseBasicParsing

ECHO Adding packages...
cd $env:userprofile\Downloads

Add-AppxPackage -Path $env:userprofile\Downloads\Microsoft.DesktopAppInstaller_8wekyb3d8bbwe.appxbundle

#Install programs and return script execution to normal condition#
winget search Piriform.Speccy

winget install Piriform.Speccy
winget export -o C:\list.txt

Set-ExecutionPolicy Restricted

ECHO "Install complete, enjoy winget"